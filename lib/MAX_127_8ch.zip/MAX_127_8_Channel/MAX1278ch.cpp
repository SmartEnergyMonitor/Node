/* MAX127.h library for Microchip DAC
   by Aitor Sierra
   Version: 1.0*/

   /* Modified 26th October 2018 by Elias Pinheiro to add 8 channel support*/

#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

#include <MAX1278ch.h>
#include <Wire.h>

// 7 bit address

MAX127::MAX127(byte address) {
	_address = address;
	Wire.begin(D1, D2);
	if (DEBUG)
		Serial.begin(115200);
}

/* Control byte format
   ___________________________________________________________________
   | Bit 7 | Bit 6 | Bit 5 | Bit 4 | Bit 3 | Bit 2 |  Bit 1 |  Bit 0 |
   |_______|_______|_______|_______|_______|_______|________|________|
   | START |  SEL2 |  SEL1 |  SEL0 |  RNG  |  BIP  |   PD1  |   PD0  |
   |_______|_______|_______|_______|_______|_______|________|________|

   Bit 7 - START - The logic �1� received after acknowledge of a write bit (R/W = 0) defines the beginning of the control byte.
   Bit 6/5/4 - SEL2/SEL1/SEL0 - These three bits select the desired �ON� channel
   Bit 3 - RNG - Selects the full-scale input voltage range
   Bit 2 - BIP - Selects unipolar or bipolar conversion mode
   Bit 1/0 - PD1/PD0 - These two bits select the power-down modes

   Examples
   Read from channel 0 with full voltage input range and normal operation (always on):
   10001000 => controlByte = 0x88;
   Read from channel 5 with full voltage input range and normal operation (always on):
   11011000 => controlByte = 0xD8;

   Further details: https://datasheetspdf.com/pdf-file/447134/Maxim/MAX127/1

   Added by Elias Pinheiro 26th October 2018
*/

int MAX127::readDAS(byte channel) {
	numBytes = 2; // number of Bytes to read
	controlByte = CONTROLBYTE | (channel << 4);
	if (DEBUG)
	{
		Serial.print("Control Byte: ");
		Serial.println(controlByte, HEX);
	}
	Wire.beginTransmission(_address);
	Wire.write(controlByte);
	Wire.endTransmission();
	Wire.requestFrom(_address, numBytes);
	MSB = Wire.read();
	LSB = Wire.read();
	MSByte = 0;
	MSByte = MSB << 4; // Shift to the left 4 bits for MSByte
	LSByte = LSB >> 4; // Shift to the right 4 bits for LSByte
	data = MSByte | LSByte;
	if (DEBUG) {
		Serial.print("MSByte: ");
		Serial.println(MSByte, HEX);
		Serial.print("LSByte: ");
		Serial.println(LSByte, HEX);
		Serial.print("Data: ");
		Serial.println(data, HEX);
	}
	return data;
}
